# Security policy

## Supported versions

The SDK is not published to npm. Security fixes are supported on the latest
reviewed commit of the `main` branch; consumers must pin an exact commit and
update deliberately. Version `0.9.0-rc.3`, SDK contract `2.1.0`, is the
current private source candidate. It adds no-network consumer test fixtures
and responsibility/compatibility documentation to the RC2 behavior, and moves
package tooling support from end-of-life Node 18/20 to Node 22/24/26.
The test fixtures default to a credential-free cookie session; legacy bearer
mode requires an explicit test token. They install no globals, start no login
flow, and are available only through `@joow/sdk/testing`.

The previous exact `0.9.0-rc.2` source includes constrained tool/knowledge declarations,
the closed 27-kind card vocabulary, authenticated card publication, exact
app-side tool-token verification, durable effect idempotency orchestration,
private call-scoped card publication, the browser-safe default `fetch`
receiver, and zero-network wallet behavior. Exact source
`ede25c539b1890e39ce48224bed8c50b30a9e7f9` (tree
`80929810e0eed87873b1a7c6a9339d5e87145769`) passed ordinary CI
`29502899659` with 127 deterministic tests, strict typecheck/build, package
allowlisting, and the clean runtime audit. Local full/runtime audits, exact
archive checks, and packed-consumer verification pass. The exact private
tarball SHA-256 is
`79aeb51a2761b6d2027301ce60eca49e2e856510b8485ed17b3f35268381aa77`.
The evidence-document successor is not a replacement package source; consumers
must pin the exact code commit above.

The preceding 0.8.0 source-authority code
`b08ceb3c51910c3172f10cf1c57fe4135744a39d` passed CI `29399715353` and
private no-publish RC `29399761221` with 109/109 tests. The original 0.8.0 provenance revision
`d1de83a7e9d959bdc1824ee41e97f1df939eb0e7` and its CI `29394503122` /
private RC `29394699044` remain historical evidence. Version 0.7.0's first
code revision `9e63fca934620714cfc5efe1b37b9bba08db3031` passed CI run
`29360454384`. The package is UNLICENSED, unpublished, untagged, and
undeployed; no pushed JooW root adoption of 0.9.0-rc.1 is claimed. Version 0.6.0 is
the historical host-synchronized candidate: root `5d280714` passed targeted stage run
`29347541134` for JooWFak `d011ca0`. That evidence does not prove 0.7.0 host
adoption, and the full public/multi-app browser matrix remains open. Production
was unchanged.

RC1 revision `d7fe1069ded6c2355733d897c5e6557f858c3f1b`, tree
`ae4a17af0e65d7b1bb80a4860a0ab4822c96723a`, and CI `29483906690`
remain historical exact evidence. The later browser correction source
`446733126b335615ff142d429dfef0b5ad3301bf` passed CI `29496161862`
with 115/115 tests and is incorporated into RC2.

## Reporting a vulnerability

Do not open a public issue for a suspected vulnerability. Use GitHub's private
vulnerability-reporting / Security Advisory flow for
`shooji-SENEX/joow-sdk-ts` and include:

- the exact SDK commit and affected host/app version;
- a minimal reproduction with secrets and personal data removed;
- the expected and observed origin, source window, signal, or HTTP behavior;
- impact and any known workaround.

Do not test against `joow.org`, another person's account, or production data
without written authorization. Use an isolated local or staging environment.

## Security invariants

- A launch handle is single-use, short-lived, delivered by `postMessage` only,
  and never accepted from a URL or persisted in storage.
- Every inbound frame message must match the exact canonical HTTP(S) origin and
  exact expected `WindowProxy` source before its payload is normalized.
- Cookie mode exposes no token to JavaScript and sends no Authorization header;
  bearer-token exchange responses fail closed unless a pre-v2 migration
  explicitly enables `allowLegacyBearer`.
- Public human identity is pick-listed and requires `identity.read`. Active
  community is separately pick-listed tenant/session context and does not
  require a human-identity grant; arbitrary host fields and raw PII are never
  forwarded.
- Mutable host-to-frame messages are rejected unless their app, appId,
  surface, and bridge-v4 context exactly match the mounted frame.
- Device context is a host-derived layout projection only. It accepts a closed
  mobile/tablet/desktop mode and bounded viewport/pixel-ratio fields; no
  user-agent, hardware model, OS version, stable device id, or raw screen
  object crosses the SDK boundary.
- Identity and discovery HTTP calls use only app-session-scoped callbacks.
  Discovery input is bounded locally and may assert, but never override, the
  active app-session community.
- Server-side public identity is limited to `displayName`/`avatarUrl` under
  `identity.read`. Private/contact attributes require a trusted app session,
  host-stamped `first_party`, the exact no-alias `identity.attributes` grant,
  and explicit helper opt-in; any missing signal fails closed.
- The current host producer resolves permitted relative avatar paths against
  the verified JooW origin and emits only absolute HTTP(S) values. The SDK then
  independently pick-lists the two public fields, requires `identity.read`, and
  retracts the cached card when the grant disappears.
- SDK-observed API 401s request a fresh launch with an exact app/surface/v4
  `joow:auth-expired` envelope; requests are deduplicated until the next launch.
- Realtime supplies no raw socket transport and exposes no client method for
  retrieving a raw delegated credential. Adapter contract v1 passes one
  immutable delegated token plus exact
  app/surface/community/subject/session-generation/operation/resource context
  atomically into every open/send/list/subscribe call. Legacy or incomplete
  adapters fail type and runtime version checks. Reads use `subscribe`, writes
  use `publish`; a logical resource is never inferred from an opaque transport
  room ID. Open results, history/live events, and publish acknowledgements must
  echo both exact values. Crossed handles, collisions, or malformed envelopes
  fail closed, revoke local authority, and request exact platform grant
  revocation for manual/disposed/authorization-failed/resource-mismatch
  teardown.
- Delegated token, subject, type, URL metadata, expiry, resources, and room IDs
  are type/character/length bounded. Accepted token expiry is capped at 150
  seconds; issuer URLs are safe-scheme validated but discarded, and the trusted
  adapter pins its own transport endpoint. Token cache, concurrent issuance,
  unique targets, rooms, and subscriptions have hard caps. Generation-guarded
  expiry callbacks cannot revoke newer sessions. Any realtime platform 401,
  session transition/expiry, mismatch, or terminal disposal clears active
  authority; new operations wait for mandatory adapter teardown.
- Current JooW source implements signed exact resource/action claims and a
  resource/subject revocation epoch, plus app-release resource authorization.
  This package sends exact mint/revoke bodies, but the extracted realtime edge
  and stage acceptance are not yet proven. The raw-token adapter contract is
  approved only inside a host-trusted realm: local binding is defense in depth,
  not a hostile-app authorization boundary. End-to-end authoritative denial,
  revocation, reconnect, origin/relay, transport and multi-actor proof remain
  open before external adoption.
- `joow:work-status` is an exact app/surface/version-bound advisory envelope;
  its top-level state key is `status`. `joow:close-imminent` is a non-vetoable,
  best-effort cleanup notice; the host owns termination. Within that notice the
  SDK gives app cleanup at most 50 ms, then terminally and idempotently disposes
  bridge, context, timers, subscriptions, room handles, and adapter authority
  even when app cleanup hangs. Callback rejection or timeout is reported only
  after disposal.
- Expected authorization failures are deny-by-default and non-enumerating.
- Tool declarations accept relative private POST paths only. Tool names and
  localized text are bounded; surface, effect, object-shaped schemas, result
  bytes, timeout, and card kinds are validated; app-authored knowledge is immutable digest-pinned JSONL
  below the reserved knowledge path and may reference only declared tools.
  These declarations are untrusted data, not instructions or execution
  authority.
- Tool runtime verification is verifier-only and HS256-compatible with the
  current broker. It requires the exact call header, rejects a conflicting
  Authorization bearer, verifies the separately scoped card-sink token, and
  binds both to app, tool, surface, active release, exact wire-input hash, D11
  subject, community, locale, call id, issuer/audience, and a bounded lifetime.
  No signer or raw-token accessor is exported. Canonical JSON hashing is a
  separate app-audit value until the Go broker adopts it in a coordinated
  contract version.
- The current symmetric verifier cannot cryptographically distinguish the
  platform from an app process that already holds the same HS256 secret. The
  SDK intentionally provides no signer, but possession of symmetric key bytes
  makes mathematical self-signing possible outside the SDK. Tool endpoints
  must remain network-private to the broker. The platform's persisted exact
  sink-token digest rejects app-forged sink tokens; eliminating call-token
  self-forgery still requires an asymmetric issuer, mTLS, or another
  independent platform proof.
- Effectful tool acknowledgement is generated only by the high-level wrapper
  after an app-provided durable store atomically reserves the exact call and
  durably commits or reloads the output. Store failures and invalid outputs
  return no acknowledgement. The SDK cannot prove that an implementation is
  actually durable; in-memory stores are forbidden outside tests.
- The asynchronous card sink retains its bearer privately, refuses redirects,
  does not retry automatically, checks expiry and declared kinds, and accepts
  only the exact call-scoped platform acknowledgement. Apps must still prevent
  their web framework, reverse proxy, tracing, crash reporting, and access logs
  from recording inbound tool headers.
- Framework adapters should use `readBoundedToolBody()` or an equivalent
  streaming limit before buffering/parsing the request. The handler repeats
  the byte check and schema validation, and the built-in sink bounds a standard
  Fetch response stream before decoding.
- Card publication requires the exact `cards.publish` session grant and exact
  app-session callback. Apps cannot self-stamp provenance; the SDK accepts only
  the closed 27 kinds and revalidates the platform acknowledgement. Writes,
  payments, messages, matchmaking, calls, and other external effects still
  require a separately enforced confirmation/exactly-once platform path; the
  SDK cannot make that policy decision itself.

## Public-boundary gaps

- Three reviewed pilot apps are not a public admission program. Trust-tier
  eligibility, conformance admission, recertification, revocation, incident
  response, and support ownership remain release gates for external apps.
- Exact frame origins and app-session scoping are implemented, but the current
  stage apps still share a Docker network and database server, with a platform
  superuser residual. Hostile-tenant containment and per-app ingress/egress
  policy are not proven.
- The current local SDK 0.9.0-rc.3 candidate and broader JooW root frontend both
  report zero vulnerabilities in full and runtime-only package audits. The
  root's historical 2026-07-14 development-tool snapshot (three high and one
  moderate, with a clean runtime audit) was resolved on 2026-07-15; it is not a
  current release gate. Dependency and secret review remain required before a
  public release.
- GitHub-hosted cryptographic artifact attestations are unavailable for this
  user-owned private repository without Enterprise Cloud. The private RC
  workflow therefore emits an explicitly unsigned source-bound in-toto/SLSA
  statement and records the retained artifact digest. Signed provenance remains
  a public-release gate; do not describe that metadata as an attestation.
- Contract 2.1 SDK runtime support is not proof of platform availability. The
  app-side verifier/idempotency/card-sink helper is locally tested, but
  consuming apps still need durable store implementations and framework log
  redaction. Stage adoption of the host broker, confirmation recovery,
  reviewed knowledge ingestion, card delivery/acknowledgement, generic
  CardHost, and hostile-origin/revocation/reconnect evidence remain release
  gates.
- Wallet methods are deliberately zero-network. Existing
  `joow_credit_accounts`/`joow_credit_ledger` signup-credit persistence is not
  an app wallet API. A live read requires an authenticated app-session,
  active-community-scoped host handler; any mutation additionally requires a
  reviewed ledger service, Twin confirmation, durable idempotency, and a rule
  that apps cannot mint credit or move fiat.

See the tests under `src/__tests__` for executable regression coverage.
