# Compatibility matrix

This file records protocol compatibility, not deployment or public-package
availability. The host remains authoritative for admitted capabilities and
managed services.

## Current private candidate

| Item | Value |
|---|---|
| Package | `@joow/sdk` `0.9.0-rc.3` |
| SDK contract | `2.1.0` |
| Frame bridge | signals/app-session v4 |
| Authentication | Embedded JooW launch; cookie session by default |
| Module format | ESM |
| Runtime dependency | Platform `fetch` only |
| TypeScript | Strict declarations built with TypeScript 5.9 |
| Node support | Active Node 22/24/26 lines; ordinary CI covers all three |
| Consumer testing entry point | `@joow/sdk/testing` |
| Distribution | Private source candidate; no tag or registry publication |

`0.9.0-rc.3` adds consumer test fixtures and boundary documentation, and
replaces end-of-life Node 18/20 support with the active Node 22/24/26 lines. It
does not change SDK contract `2.1.0`, bridge v4, session wire shapes, host
routes, capability semantics, or the existing server-only tool runtime.

## Backward-compatible app rollout

Existing applications are not required to repin during the platform release.
The exact private RC1 and RC2 archives remain valid contract-2.1/bridge-v4
consumer coordinates, and their current immutable app pins are preserved.
RC3 adds an optional test-only subpath; it removes or renames no existing
runtime export and changes no browser wire shape.

An app should adopt RC3 only in a separate reviewed commit when its build
toolchain uses Node 22 or newer and it needs the new testing fixtures. Apps that
remain on RC1/RC2 continue to interoperate with the same host contract. This is
the compatibility adapter/version path for the current rollout; a mass archive
replacement is neither necessary nor authorized.

## Host compatibility rule

The SDK contract major must equal the host major. The SDK minor must be less
than or equal to the host minor; patch versions do not change wire
compatibility. Package SemVer and SDK contract version are separate.

An app must also verify:

- its exact manifest contract and capability grants;
- the bridge version and exact host/app origins;
- cookie-session exchange and renewal behavior;
- any optional service/client contract it actually uses;
- the SDK package version or exact reviewed source commit it pins.

## Entry-point environments

| Entry point | Environment | Notes |
|---|---|---|
| `@joow/sdk` and browser client subpaths | Browser/app frame | No provider credentials or standalone auth; the root still has compatibility-only server-tool re-exports that browser consumers should not use |
| `@joow/sdk/manifest` | Authoring/build tools | Mirrors the current host manifest authority |
| `@joow/sdk/conformance` | Build/test tooling | Reports contract findings; it does not admit or deploy an app |
| `@joow/sdk/testing` | Tests only | No network, globals, login flow, or generated production credential |
| `@joow/sdk/tools` and its current root re-exports | Server-side Node compatibility surface | Frozen exception pending extraction to a Node runtime package |

## Runtime-kit status

The proposed Node and Go runtime kits are not released by this candidate. An
app must not import a guessed module path or copy an unreleased adapter. Their
first release requires independent versioning, contract fixtures, CI, and at
least one clean consumer example.

## Previous candidate

`0.9.0-rc.2` remains the previous exact private evidence candidate. Its source,
CI run, tarball digest, and limitations remain recorded in [RELEASE.md](./RELEASE.md).
Do not rebuild a later tree under the `0.9.0-rc.2` identity.
