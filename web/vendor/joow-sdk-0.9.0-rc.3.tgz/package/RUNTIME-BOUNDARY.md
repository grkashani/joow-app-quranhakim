# SDK and app-runtime boundary

## Decision

JooW app integration is split by execution boundary and language:

| Component | Responsibility | Release unit |
|---|---|---|
| `@joow/sdk` | Browser launch/session, frame bridge, host context, capability-gated browser clients, manifest authoring, conformance, consumer test fixtures, and the existing server-tool compatibility exception described below | This TypeScript package |
| `@joow/app-runtime-node` | Proposed generic Node backend helpers | A future independently versioned package |
| `github.com/shooji-SENEX/joow-app-runtime-go` | Proposed generic Go backend helpers | A future independently versioned Go module |
| JooW host/platform | Canonical schemas, request authority, service bindings, scoped credentials, admission, and managed infrastructure | Host-owned contracts and services |
| App repository | Domain model, schema/migrations, business authorization, provider adapters, and product UI | App-owned source and runtime image |

In the target architecture, the browser SDK and backend runtime helpers do not
share a release number. The existing server-tool exception is migrated rather
than removed abruptly.
Different languages and trust boundaries need independent compatibility and
support policies. Cross-repository consumers pin an immutable version and use
canonical host fixtures to prove compatibility.

## Browser SDK scope

The SDK may:

- exchange a verified launch handle for the cookie-based app session;
- enforce exact frame origin, source, app, surface, and bridge context;
- expose pick-listed appearance, device, community, and public-user context;
- gate a browser operation before it leaves the client;
- return opaque host handles and typed status values;
- mirror canonical manifest schemas for authoring after the host schema exists;
- provide deterministic no-network consumer fixtures through
  `@joow/sdk/testing`.

The SDK must not:

- hold provider secrets, OAuth codes/tokens, storage credentials, or database
  connection strings;
- implement PostgreSQL, vault, provider-connection, worker, object-scanning,
  delivery, or deployment behavior;
- mark a capability live before the host can mint and enforce it;
- guess a host route or response shape ahead of the canonical host contract;
- add standalone authentication or a production mock fallback.

## Existing server-only compatibility surface

`@joow/sdk/tools` predates this split. It is a server-only TypeScript verifier
and orchestration helper for SDK contract 2.1 app tools. Its symbols are also
re-exported from the package root for source compatibility. They are not
browser APIs and browser consumers should not import them.

For compatibility:

1. keep the existing entry point supported for the current SDK contract;
2. freeze its scope—new generic backend features do not go into the browser
   SDK package;
3. create `@joow/app-runtime-node` when another generic Node runtime feature is
   ready;
4. move the tool runtime in a coordinated release and retain deprecated
   subpath and root re-exports for at least one SDK minor;
5. implement language-equivalent Go behavior from canonical host fixtures,
   not by translating or embedding the TypeScript runtime.

## Runtime-kit shape

A runtime kit should be thin and composable. It accepts explicit dependencies
and `context.Context`/request context, returns typed errors, and never owns an
application's global logger, telemetry provider, domain transaction, schema,
or unstoppable background worker.

The first reusable packages should cover:

- trusted app request context and current proxy-proof verification;
- typed configuration and redacted diagnostics;
- bounded HTTP/problem responses and graceful shutdown;
- liveness/readiness checks;
- PostgreSQL pool/readiness/transaction primitives without app migrations;
- the governed JooW AI gateway client without a direct-provider fallback;
- injected OpenTelemetry hooks and a small common audit envelope;
- canonical no-network conformance fixtures.

Clients for secrets, provider connections, private objects, scanning, and
delivery wait until their platform contracts are versioned. A runtime kit does
not invent those services.

## Compatibility workflow

1. The host publishes a versioned schema and canonical success/failure
   fixtures.
2. SDK/runtime packages implement those fixtures and publish compatibility
   ranges.
3. Apps pin exact package versions and run the same fixture suite against local
   fakes.
4. Stage acceptance exercises the real host/service implementation.
5. Removing a compatibility path requires a documented deprecation window and
   proof that supported consumers migrated.

See [COMPATIBILITY.md](./COMPATIBILITY.md) for the current matrix.
