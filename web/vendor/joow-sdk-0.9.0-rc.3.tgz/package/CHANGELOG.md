# Changelog

## 0.9.0-rc.3 - 2026-07-17

- Add an idempotent `sdk.cards.acknowledge(cardId)` callback bound to the exact
  authenticated app/session/D11 subject/community scope; retain the existing
  `cards.publish` capability as an exact grant with no legacy widening.
- Add the explicit `@joow/sdk/testing` subpath with no-network transport,
  frame-message, postMessage, response, and cookie-session fixtures for app
  consumer tests.
- Keep test sessions credential-free by default and require an explicit token
  for the migration-only legacy bearer fixture.
- Document the browser SDK, existing server-only `@joow/sdk/tools` exception,
  future Node/Go runtime kits, host service-contract authority, and app-domain
  ownership boundary.
- Add a package/host compatibility matrix and packed-consumer coverage for the
  new test-only entry point.
- Replace end-of-life Node 18/20 support with the active Node 22, 24, and 26
  lines in ordinary CI; private RC evidence uses an exact Node 22 toolchain.
- Preserve SDK contract `2.1.0`, bridge v4, host routes, session wire shapes,
  capability semantics, and existing runtime behavior. Local strict typecheck,
  build, and all 131 deterministic tests pass; pull-request CI and review remain
  required before adoption.

## 0.9.0-rc.2 - 2026-07-16

- Bind the default platform `fetch` receiver before storing it in
  `FetchTransport`, preventing browser `Illegal invocation` failures while
  leaving explicitly supplied transports unchanged.
- Add deterministic regression coverage for the browser receiver boundary.
- Add the app-backend tool runtime for contract 2.1: exact HS256
  platform-token verification, app/tool/surface/release/D11/community/locale/
  call binding, exact wire-input hashing plus a separate deterministic
  canonical JSON hash, bounded app-supplied input/output schema validators,
  and non-enumerating error responses.
- Add the durable effect wrapper. `write`/`external` tools require an
  app-supplied durable idempotency store, and the SDK emits
  `X-Joow-Idempotency-Acknowledged` only after atomic reservation and durable
  output completion or replay.
- Add a private call-scoped asynchronous card publisher. It verifies the
  separately scoped sink token, keeps the raw bearer inaccessible, disables
  redirects and automatic retries, enforces declared card kinds, and accepts
  only the exact platform acknowledgement.
- Close the wallet client's two guessed broad routes. Balance and mutation
  methods now return `not_available` without network traffic until a reviewed
  app-session-scoped internal-credit host API exists.
- Extend deterministic coverage from 115 to 127 tests, including hostile
  token/context/body cases, idempotency replay/failure, card-sink
  secrecy/expiry, streaming request/response size boundaries,
  schema/credential boundaries, and zero-network wallet behavior.
- Record exact source
  `ede25c539b1890e39ce48224bed8c50b30a9e7f9`, tree
  `80929810e0eed87873b1a7c6a9339d5e87145769`, and ordinary CI
  `29502899659`. The exact 86-file private tarball has SHA-256
  `79aeb51a2761b6d2027301ce60eca49e2e856510b8485ed17b3f35268381aa77`;
  no tag, publication, deployment, or manual RC dispatch occurred.

## 0.9.0-rc.1 - 2026-07-16

- Stamp `SDK_CONTRACT_VERSION` `2.1.0` while keeping the package private,
  `UNLICENSED`, unpublished, untagged, and undeployed.
- Add the `cards.publish` capability and an authenticated card client that
  validates locally, posts only to the exact app-session callback, and accepts
  only platform-stamped `joow.card.v1` acknowledgements.
- Close the card vocabulary to the backend's exact 27 kinds. Unknown,
  undeclared, custom `x-*`, self-provenanced, identity-leaking, and
  unconfirmed side-effect cards fail closed.
- Add contract 2.1 manifest types and validation for bilingual app tools:
  exact `/_joow/tools/<name>` private POST endpoints, bounded schemas,
  `read|write|external` effect, surface, card kinds, timeout, and response
  size.
- Add immutable app-knowledge declarations: bounded JSONL paths under
  `/_joow/knowledge/`, lowercase SHA-256 digests, EN/FA locale claims, and
  references only to declared tools.
- Extend deterministic coverage to 114 tests, including card publication,
  closed-kind acknowledgement rejection, and safe/unsafe tool and knowledge
  metadata.
- Align delegated realtime with the SDK 2.1 identity root: only canonical
  one-colon `type:id` resources are accepted, and every mint request carries
  the exact `{operation, resource}` body.
- Revoke exact active grants through the app-session callback on manual or
  terminal teardown, adapter authorization failure, and resource mismatch;
  failed revocation keeps replacement authority fail-closed.
- Update the private no-publish release-candidate workflow to verify and retain
  `joow-sdk-0.9.0-rc.1.tgz`; it still has no tag, npm publish, mirror, or
  deployment step.

## 0.8.0 - 2026-07-15

- Add `runtime.revision` to the `joow.app.v2` authoring contract. A pre-built
  digest image now requires the exact lowercase 40-hex source commit, while a
  source-built manifest must keep `runtime.source.ref` as its sole provenance
  authority.
- Add deterministic manifest tests for accepted image provenance, missing,
  short, uppercase, and branch-like revisions, and conflicting source/image
  authority. The exact pushed candidate passed 95 SDK tests, strict typecheck,
  declaration/ESM build, and clean runtime/full dependency audits.
- Mirror the Go manifest authority's `surfaces`, `proxyProof`, `presentation`,
  and `catalog` types, defaults, and validation. Catalog-only manifests now
  accept an omitted or empty runtime without weakening image/source, port,
  health, netclass, or proxy-secret binding checks for launchable apps. The
  exact code revision `f5594f311884d23cc87e32730dab68592636f4af`
  passed CI `29396959111` and private no-publish RC `29396994747` with
  102/102 deterministic tests. Retained artifact `8335515162` has GitHub digest
  `sha256:491f93c8db6b534b9874f7a787b60b34e7f706a4f0d8f197c2fb14eb4c0af35c`;
  no publication or deployment occurred.
- Complete the remaining current Go-authority validation mirror: runnable
  manifests require positive memory and CPU budgets using the exact parser
  grammar and 1 GiB/2 CPU ceilings; `realtime.send` requires
  `realtime.join`; capability-justification keys use the capability grammar;
  and source Dockerfile/context paths apply Go-compatible normalization before
  rejecting absolute, backslash, or above-root traversal. Exact revision
  `eae95bf124ece920a6c55da505e2e73211cc41a7` passed CI `29398605205` and
  private no-publish RC `29398638225` with 106/106 tests, clean full/runtime
  audits, package and archive allowlisting, packed-consumer smoke, SBOM,
  checksums, and explicitly unsigned source-bound provenance. Artifact
  `8336146396` has GitHub digest
  `sha256:522054338c37ada583a40b43ed6bdb36071d8f9174c8f79cc897854f63b6dfce`;
  tarball SHA-256 is
  `f9d31cb7766deb07c6097a4e77eaa7ed61477cbc5c117fbff99bbcc4c71c996a`.
- Final revision `eae95bf124ece920a6c55da505e2e73211cc41a7` supersedes the
  intermediate `e04fb0e64f3b81a0a696389d38eb2e21b7f40bdc`: a fresh parser
  audit confirmed Go `strconv.ParseUint` forbids a leading sign, so the final
  mirror and regression reject `+1Gi` rather than accepting it.
- Supersede that candidate with source-authority revision
  `b08ceb3c51910c3172f10cf1c57fe4135744a39d`. Repository URLs now accept only
  canonical HTTPS, SCP-style `git@host:path`, and `ssh://git@host/path` forms.
  They reject other schemes; HTTPS userinfo; non-`git` SSH users and SSH
  passwords; literal query/fragment delimiters; raw or escaped ambiguous paths;
  whitespace, Unicode, controls, and backslashes; empty host/path; trailing or
  doubled slashes; and `.`/`..` segments. Rejection errors never include the
  submitted URL or userinfo.
- Require every source-built manifest to pin an exact lowercase 40-hex commit.
  Semver-looking tags, other tags, branches, uppercase hashes, and malformed
  hashes are rejected because Git tags are movable.
- Exact revision `b08ceb3c51910c3172f10cf1c57fe4135744a39d` passed CI
  `29399715353` and private no-publish RC `29399761221` with 109/109 tests,
  clean full/runtime audits, 82-file package/archive allowlisting,
  packed-consumer smoke, CycloneDX SBOM, checksums, and explicitly unsigned
  source-bound provenance. Artifact `8336572615` has GitHub digest
  `sha256:f15f3563aedf17d400edfc4d555b4d7153ae28af7da7dcdd0df8cdc7b78d0226`;
  tarball SHA-256 is
  `6dbdf4acb9c882d21b106856abe7a138b1b815b70bd3017fd8947497b65084d0`.
- Preserve the preceding 106-test evidence: code
  `eae95bf124ece920a6c55da505e2e73211cc41a7`, CI `29398605205`, private RC
  `29398638225`, and evidence documents
  `d81bb68313b623eb59e0d7ba31a5bcf53b6ec6d7` / CI `29398772615`.
- Preserve the preceding parity evidence: code
  `f5594f311884d23cc87e32730dab68592636f4af`, CI `29396959111`, private RC
  `29396994747`, and evidence documents
  `b39e86c563f4e99ccbeeaa78854097d8fc26ecb3` / CI `29397139334`.
- Keep the package private, `UNLICENSED`, unpublished, and untagged. This
  source-label contract becomes meaningful only when the host also verifies
  `org.opencontainers.image.revision` on the exact digest-pinned image; it is
  not a cryptographic proof that the image was built from that commit.
- Exact code revision `d1de83a7e9d959bdc1824ee41e97f1df939eb0e7`
  passed CI `29394503122` and private no-publish RC `29394699044`; retained
  artifact `8334607671` has digest
  `sha256:de66032752a3c63428d45de15858acf8b3b275ab783c3c60397f04b75f82c354`.

## 0.7.0 - 2026-07-14

- Replace the authorize-then-operate realtime seam with explicit adapter
  contract v1. Every open, publish, history-read, and subscription call now
  receives one frozen object containing the delegated token and exact
  app/surface/community/subject/session-generation/operation/resource context.
  Legacy adapters fail TypeScript validation and a runtime contract check.
- Use only the backend authorizer's `subscribe` and `publish` vocabulary;
  history reads authorize as `subscribe`, and unsupported `list` authority is
  no longer representable.
- Separate logical authorization resources from opaque transport room IDs.
  `openRoom(resource)` returns a frozen bound handle; publish, history, live
  subscription, and publish acknowledgements must echo both exact values.
  Cross-resource collisions or malformed envelopes fail closed and tear down
  active authority. Reject wildcard, path-like, encoded, whitespace, Unicode,
  and control-character identifiers before token I/O.
- Remove raw delegated-token retrieval from the app client API. The credential
  is delivered only inside an atomic adapter operation, with bounded token,
  subject, token-type, URL metadata, and a 150-second maximum accepted TTL.
  Issuer URLs are validated but never exposed or used for endpoint selection.
- Bound token cache, token issuance concurrency, unique resources, room
  bindings, and live subscriptions. Sequence- and generation-guard expiry
  callbacks so stale timers cannot revoke replacement authority.
- Make adapter invalidation mandatory and serialize new operations behind old
  transport teardown. Delegated-token and app-session timers passively clear
  caches and subscriptions at expiry; any realtime platform 401 revokes local
  authority, and session expiry also prevents further minting.
- Add terminal idempotent disposal to both `RealtimeClient` and `JoowSdk`.
  `joow:close-imminent` gives app cleanup a bounded 50 ms before SDK/adapter
  teardown, so a hung callback cannot block disposal; rejection and timeout are
  reported only after teardown.
- Add a manual, no-publish release-candidate evidence workflow that builds and
  smokes the exact tarball, rejects paths outside a strict pack manifest,
  records full/runtime audits, creates a toolchain-recorded CycloneDX npm SBOM
  and SHA-256 manifest, emits and validates an explicitly unsigned
  source-bound in-toto/SLSA provenance statement, and records the retained
  artifact digest without creating a tag or publishing to npm. CI and RC
  workflows use the Ubuntu 24.04 runner label, exact Node version, and full
  action commit pins. Cryptographic private-repository provenance remains a
  release gate because GitHub's hosted attestation API requires Enterprise
  Cloud for this private repository.
- Add deterministic regression coverage for session-switch races, immutable
  in-flight authority, resource crossing, expiry, adapter compatibility, exact
  operation vocabulary, and unsafe resources.
- Keep this candidate private, UNLICENSED, unpublished, untagged, and
  unsynchronized from host/app repositories. First code revision
  `9e63fca934620714cfc5efe1b37b9bba08db3031` passed CI `29360454384`; no host
  or production adoption is claimed. The deployed delegated JWT is still not
  resource/action-signed and has no early-revocation endpoint, so authoritative
  edge checks and short TTL remain residual controls. The raw-token adapter
  contract is suitable only inside a host-trusted realm; local SDK binding is
  defense in depth, not an authorization boundary against hostile app code.

## 0.6.0 - 2026-07-14

- Add a pick-listed, host-derived `sdk.device` context for
  mobile/tablet/desktop mode, mounted viewport, orientation, pixel ratio, and
  touch state. The SDK never infers device state from user-agent or hardware
  identifiers.
- Require the exact app/appId/surface/bridge-v4 envelope on mutable
  host-to-frame appearance, capability, and auth-expiry signals as well as on
  frame-to-host signals. This is a pre-1.0 compatibility break for hosts still
  sending the retained bare forms.
- Treat the active community as tenant/session context independent of the
  human `identity.read` projection; keep it strictly pick-listed and continue
  gating the public user card on `identity.read`.
- Route `identity.me()` and member discovery only through the app-scoped
  `/api/joow/app-sessions/{app}/...` callbacks. Discovery uses the deployed
  `query` parameter, validates bounded input locally, and cannot select a
  community other than the active app-session community.
- Require delegated adapter authorization before realtime open, send, list,
  and subscribe operations; expose typed `listEvents` and async `subscribe`;
  fail closed when adapter authorization is unavailable; and partition token
  caches by session/app/surface/community/action/resource.
- Invalidate realtime tokens, in-flight issuance, and active SDK subscriptions
  on adoption, exchange, relaunch, expiry, and 401. Adapters can implement the
  additive `invalidateAuthorization` hook to drop old socket state. The current
  backend token remains app/community/capability-scoped rather than
  resource/action-signed, so authoritative edge checks are still required.
- Keep the package private, UNLICENSED, unpublished, untagged, and unsynced
  from the host. Realtime still needs a host-provided adapter and compatible
  backend/edge transport; wallet remains pilot-gated; direct uploads and card
  publication remain unavailable. These are explicit public-release blockers,
  not completed SDK capabilities.
- Refresh the locked GitHub CI workflow to the current Node 24-based v7
  checkout/setup actions while continuing to test the SDK itself on Node 20.

## 0.5.1 - 2026-07-14

- Require trusted app-session evidence, a host-stamped `first_party` tier, the
  exact `identity.attributes` capability, and explicit caller opt-in before
  `readTrustedContext` exposes private/contact identity attributes.
- Keep `displayName` and `avatarUrl` as the separate `identity.read` public
  projection; broad legacy capabilities never imply private attributes.
- Add `identity.attributes` to the capability catalog with no legacy aliases,
  plus fail-closed regression coverage for missing/malformed boundary evidence.
- Keep the package private, UNLICENSED, and unpublished. Per-user
  consent/revocation for private attributes remains a host release blocker if
  required by policy.

## 0.5.0 - 2026-07-14

- Make one-time launch handles `postMessage`-only; URL parsing/storage can no
  longer recover or persist credentials.
- Auto-exchange verified launches into cookie-first/no-token sessions before
  emitting `joow:ready` or `joow:bridge-ready`, and omit the consumed handle
  from the high-level app bootstrap callback.
- Reject legacy bearer exchange responses by default; retain an explicit
  `allowLegacyBearer` pre-v2 migration opt-in.
- Require exact canonical host/app origins and exact parent/frame sources.
- Require configured, signaled, response, and legacy-token app/surface context
  to agree before adopting a session.
- Add frame-side relaunch and host-side relaunch-request APIs using the live
  `joow:auth-expired` recovery signal. SDK-observed cookie API 401s share one
  bounded exact-launch renewal, retry once only after verified exchange, and
  reset after timeout or bootstrap failure.
- Require the full exact app/appId/surface/v4 envelope on every app-to-host
  signal; host helpers reject bare, aliased, or wrong-context messages.
- Expose the production shell's exact-context, image-only (<=10 MiB) upload
  adapter with HTTPS-result validation, timeout, and close cleanup. The
  undeployed direct HTTP upload path now returns `not_available` without I/O.
- Enforce manifest `declaredKinds`; card publication is explicitly reserved
  and returns `not_available` without calling a guessed backend route.
- Add the retained-app-compatible, context-bound `joow:work-status` wire with
  top-level `status`, plus non-vetoable `joow:close-imminent` cleanup handling.
- Pick-list capability-scoped public user and active-community launch context.
- Align the app-session bridge header version with signals v4.
- Add security, release, license, plan, and knowledge-graph documentation.

This version was an internal, private release candidate, was not published, and
is superseded by the 0.5.1 security-hardened candidate.

## 0.4.0

- Add the appearance plane and public user-card bridge.

## 0.3.0

- Add cookie-mode app-session auth, surface grants, ICE servers, and typed
  session expiry.
