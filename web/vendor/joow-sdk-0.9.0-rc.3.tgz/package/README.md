# @joow/sdk

Private TypeScript SDK release candidate for the JooW **`joow.app.v2`**
mini-app boundary and SDK contract **`2.1.0`**. It is the
non-Dart re-issue of `packages/joow_app_sdk` (Dart v1 → **reference-only**,
`v1-DEPRECATED`). Runtime/session behavior mirrors the reviewed app-host
boundary; contract 2.1 tool, knowledge, and card-publish support remains a
candidate until the separately owned host, broker, and mini-app adoption gates
pass.

- **Runtime deps:** the platform `fetch`, and nothing else.
- **Module system:** ESM, strict TypeScript.
- **Bridge:** the frame↔shell `postMessage` protocol uses the **signals v4**
  base (`bridgeVersion: 4`) plus additive JooW work/close lifecycle signals.
- **Auth:** **embedded only**. JooW auth is the sole authority (see below).

```
npm install        # installs the one devDependency (typescript)
npm run typecheck  # tsc --noEmit  — the contract gate
npm test           # tsc + node --test (built-in runner, zero extra deps)
npm run build      # emit dist/ (ESM + .d.ts), tests excluded
```

## Consumer test fixtures

Use the explicit test-only subpath for deterministic app tests:

```ts
import {
  TestTransport,
  createTestSession,
  testJsonResponse,
} from "@joow/sdk/testing";

const transport = new TestTransport(() =>
  testJsonResponse(200, { ok: true }),
);
const session = createTestSession({
  appId: "mail",
  capabilities: ["mail.read"],
  community: { id: "community-1", role: "member" },
});
```

Fixtures perform no network I/O, install no globals, and create a credential-
free cookie session by default. A legacy bearer fixture requires an explicit
token on every call. The testing API is not re-exported from the package root,
so production imports remain visibly separate.

## Distribution status

Version `0.9.0-rc.3` is the current private source candidate for SDK contract
`2.1.0`. It adds the explicit `@joow/sdk/testing` consumer surface plus the
SDK/runtime responsibility and compatibility documents, and moves package
tooling support from end-of-life Node 18/20 to Node 22/24/26. It deliberately
does not change the host wire contract, bridge v4, session model, capability
semantics, or existing `@joow/sdk/tools` behavior. The new candidate must pass
its own pull-request CI and review before a consumer adopts its exact commit.

The GitHub repository and package remain private, `private: true`,
`UNLICENSED`, unpublished, untagged, and undeployed. Internal consumers may
use only an exact reviewed Git commit or checked-in source snapshot. No tag,
registry publication, public license grant, JooW root synchronization, stage
deployment, or production change is implied by this candidate.

See [COMPATIBILITY.md](./COMPATIBILITY.md) for the version matrix and
[RUNTIME-BOUNDARY.md](./RUNTIME-BOUNDARY.md) for the browser SDK, Node runtime,
Go runtime, platform, and app ownership split.

### Previous 0.9.0-rc.2 evidence

Exact source `ede25c539b1890e39ce48224bed8c50b30a9e7f9` (tree
`80929810e0eed87873b1a7c6a9339d5e87145769`) passed ordinary CI
`29502899659`: locked install, strict typecheck, all 127 deterministic tests,
declaration/ESM build, package allowlisting, and the clean runtime audit. Its
exact 86-file private tarball is 181,080 bytes packed / 748,416 bytes unpacked
and has SHA-256
`79aeb51a2761b6d2027301ce60eca49e2e856510b8485ed17b3f35268381aa77`.
That evidence remains tied to RC2's exact source; do not rebuild a later tree
under the same package version.

### Historical 0.8.0 standalone evidence

The preceding `0.8.0` source-authority revision
`b08ceb3c51910c3172f10cf1c57fe4135744a39d` passed CI `29399715353` and
private no-publish RC `29399761221` with 109/109 tests. Retained artifact
`8336572615` has GitHub's server-computed digest
`sha256:f15f3563aedf17d400edfc4d555b4d7153ae28af7da7dcdd0df8cdc7b78d0226`;
the contained private tarball has SHA-256
`6dbdf4acb9c882d21b106856abe7a138b1b815b70bd3017fd8947497b65084d0`.

The preceding validation-authority revision
`eae95bf124ece920a6c55da505e2e73211cc41a7` passed CI `29398605205` and
private RC `29398638225` with 106/106 tests; its evidence-document revision
`d81bb68313b623eb59e0d7ba31a5bcf53b6ec6d7` passed CI `29398772615`.
The catalog/surface/proxy-proof/presentation parity revision
`f5594f311884d23cc87e32730dab68592636f4af` passed CI `29396959111` and
private RC `29396994747` with 102/102 tests; its evidence-document revision
`b39e86c563f4e99ccbeeaa78854097d8fc26ecb3` passed CI `29397139334`.
The original image/source provenance revision
`d1de83a7e9d959bdc1824ee41e97f1df939eb0e7` passed CI `29394503122` and
private RC `29394699044` with 95/95 tests. These historical revisions remain
valid evidence but are superseded by the 109-test follow-up. This is private
evidence, not a package release or deployment claim. Version
`0.7.0`'s first reviewed
code revision, `9e63fca934620714cfc5efe1b37b9bba08db3031`, passed standalone
CI run `29360454384`; it has not been mirrored into JooW, deployed, or adopted
by any host/app. The GitHub repository itself is **private**, and the npm
package remains `private: true`, `UNLICENSED`, unpublished, and untagged. The
current follow-up replaces a GitHub-hosted attestation step that the repository
plan cannot use with explicit unsigned source-bound provenance metadata and a
server-computed retained-artifact digest. JooW repos consume only an exact
reviewed Git commit (or a checked-in source copy) after its required CI/evidence
run succeeds.
Public npm publication is blocked until an owner opens an approved distribution
path, selects a license and registry/access policy, enables provenance and
trusted publishing, and completes the checklist in [RELEASE.md](./RELEASE.md).
`npm pack --dry-run` verifies the future tarball without publishing it.

The package source/documents were synchronized through JooW root candidate
`6dfefb29b1dde21c7ad43aa4272965fbf6065091`; the accepted targeted successor is
root `5d2807149cc40aaeb04cfd05f6d681a4c6e13533`, whose stage run
`29347541134` succeeded with JooWFak runtime
`d011ca049b4d031b8fd185f87ac338a73bcb1d79` after app CI `29346907089`.
Signed-in stage proof covered canonical `identity.read`, `realtime.join` and
`realtime.send`, public-card propagation with the expected fallback plus
locale/theme/device propagation, search without a standalone-account/name
prompt, yellow Working plus the force-close warning, and cancel returning to
idle. The live host profile had no uploaded avatar, so this browser slice did
not prove an avatar image load; relative-avatar normalization is covered by
static/CI tests. JooWFak documentation was subsequently recorded at
`32055789603a5b0ee74d7915f3ecce1aeb0ac025`, while the runtime manifest remains
pinned to `d011ca0`. Production was unchanged. This targeted slice is not a
package tag, publication, license grant, public SDK release, or the complete
three-app compatibility matrix.

### Historical 0.6.0 mini-app provider/adoption evidence

The following independent source candidates passed their own CI with the
0.6.0 exact-context provider boundary. Their CI is historical
source/adoption evidence, not 0.7.0 adoption; JooWFak additionally has the
targeted accepted stage proof recorded above:

| Mini app | Exact source / CI | Provider contracts exercised | Still open |
|---|---|---|---|
| TimeBank | `eff81067d7f2a6e732c010eb2c518e6e039c5a4e` / `29343715025` | Public identity with live retraction, locale/theme/device, session renewal, work/close, host image upload, local card validation | Live responsive/upload/restore proof and host card ingestion plus acknowledgement |
| JooWFak | `d011ca049b4d031b8fd185f87ac338a73bcb1d79` / `29346907089` | Self-only public name/avatar, D11 pseudonymous peer identity, locale/theme/device, work/close, delegated realtime/ICE and exact join/send grants; targeted root stage run `29347541134` passed | Two-actor realtime/WebRTC/TURN proof and the broader app/surface/reload/expiry matrix |
| KhodroJoow | `625ef849d62418a7d2364189cb1958ed98631d41` / `29341691350` | Multi-surface identity, locale/theme/device, lifecycle/work/close, realtime, GPT and upload contracts | Accepted four-surface stage/browser proof and remaining app-owned WS/AI/upload integration |

Because no public artifact exists, this is protocol/provider adoption evidence;
some apps use reviewed repo-local adapters rather than importing a published
npm package.

The canonical public identity card is only `{ displayName?, avatarUrl? }` under
`identity.read`; the SDK pick-lists it and retracts it when the grant disappears.
The current host producer resolves an allowed relative avatar against the
verified JooW origin into an absolute HTTP(S) URL and drops non-HTTP(S) values.
This card is display context, never an account identifier: app/session identity
remains the D11 app-scoped pseudonym.

The historical 2026-07-14 JooW root development-tool advisories were resolved
on 2026-07-15. Current JooW root frontend and standalone SDK full/runtime audits
each report zero vulnerabilities, so that audit-specific publication gate is
closed. Public distribution remains blocked by owner-controlled repository and
package decisions: an approved license, npm organization/ownership/access and
support policy, public-readable or otherwise approved immutable source access,
and protected release/provenance authorization. Separately, unavailable wallet,
partial realtime transport, incomplete durable card-sink/CardHost/confirmation
adoption, external app trust/admission, and hostile-tenant isolation remain feature/adoption gaps;
do not claim those capabilities generally available until their platform gates
and compatibility evidence pass.

Historical host adoption evidence (2026-07-14): the main JooW tree containing the
synchronized 0.5.1 identity boundary reached stage at revision
`b0a92dc4ff8a47a90682da2a7cbf320436b61a53` through full workflow
`29301375540`, including backend/SDK checks, stage reconcile, and the
production-health guard. Runnable manifests request no `identity.attributes`;
JoowFak also drops `identity.read`, while KhodroJoow's remaining
`identity.read` can expose only the public display/avatar projection. This is
host-adoption evidence, not public release approval or exhaustive compatibility
proof for 0.6.0. Per-user consent/revocation policy and the full three-app/public
compatibility matrix remain open despite the targeted JooWFak stage pass above.

The final signed-in smoke at that host revision also proved two launch paths:
`/apps/run/joowfak` cleared loading into the full anonymous-call UI, and
`/apps/run/khodrojoow` cleared loading into the complete seller dashboard.
Both retained iframes were complete, the host showed no Back/topbar, and the
exact JooW exit was present. This remains partial compatibility evidence only:
JoowFak still runs its older local-embedding pin, destructive force-close was
not exercised, and the exhaustive app/surface/reload/auth/upload/origin matrix
is still a release gate.

## Security model (the public-integrator contract)

If you integrate a mini-app with JooW, these are the non-negotiables your app
is built — and reviewed — against:

1. **Cookie-only auth, zero raw credentials in app code.** The deployed v2
   exchange (`POST /api/joow/app-sessions/exchange`) returns **no token** —
   deliberately. Your session is an **HttpOnly `joow_app_session` cookie**,
   path-scoped to your own mount (`/api/joow/apps/<app>/`) and your platform
   callbacks (`/api/joow/app-sessions/<app>/`) and nothing else. The SDK sends
   every request with `credentials: "same-origin"` and **never** sets an
   `Authorization` header in cookie mode. Your JavaScript can neither read nor
   leak the credential. The short-lived launch handle is delivered only in an
   origin-and-source-verified `joow:launch` `postMessage`; it is never placed in
   a URL, storage, referrer, history, or access log. A pre-v2 response that
   exposes a bearer token fails closed by default; `allowLegacyBearer: true`
   is an explicit, migration-only compatibility escape hatch. New
   integrations target the cookie contract.
2. **D11 pseudonymous subject.** The only stable user identifier your app ever
   sees — `session.subject`, discovery results, realtime identities — is a
   per-`(app, community, user)` HMAC **pseudonym**. Apps **never** see raw
   platform user ids, emails, or phone numbers; two apps cannot re-link the
   same human. The SDK additionally scrubs every response and drops any
   payload carrying identity-shaped fields, even if the platform regressed.
3. **Capability-gated platform APIs.** Every platform call is gated twice: the
   SDK refuses locally (`not_allowed`) if your granted set
   (`session.surfaceCapabilities`, then `session.capabilities` — check with
   `session.grants(cap)`) lacks the capability, and the backend enforces the
   same grant server-side, deny-by-default. You get exactly what your reviewed
   manifest declares — nothing more.
4. **JooW is the sole auth authority — no standalone login.** Your app never
   renders a login/signup screen and never talks to a foreign identity
   provider. Sessions are short-TTL (15 min). When one expires, any call
   returns 401 and the SDK raises a typed `JoowSessionExpiredError`
   (`sdk.onSessionExpired(...)` / `sdk.ensureSession()`); the SDK asks the host
   to run the **launch flow** for a fresh single-use handle over the bridge.
   That app-to-host `joow:auth-expired` request carries the exact app,
   appId, surface, and bridge-v4 context. Concurrent callers share one bounded
   5-second wait. Only a successfully exchanged, exact-context cookie launch
   releases them; each original 401 is retried once, and timeout/failure clears
   the flight so a later call can request another launch.
   There is deliberately no silent re-auth and no refresh token.
5. **Audit and approval to go live.** Only registry-approved,
   operator-enabled apps with a launchable runtime are launchable. Trust tier
   scopes the boundary and data access; it is not a `first_party`-only launch
   gate. The approved JoowFak and KhodroJoow partner pilots are runnable under
   their reviewed constraints. Your manifest, declared capabilities, and
   conformance results (`runConformance`) are what the platform audits; an
   unapproved, disabled, or unhealthy app simply does not launch.

## Auth authority — embedded ONLY

**JooW auth is the only auth authority.** This SDK authenticates EXCLUSIVELY
through the signed app-session boundary (`AUTH_MODE === "embedded"`): the shell
mints a one-time launch handle, posts it to the exact frame, and the exchange
installs a cookie while the mount mints trusted `X-Joow-*` headers carrying a
per-`(app, community, user)` **pseudonym**. There is deliberately **no**
`bearer` / `edge` / `standalone` / `joowcore-issuer` mode — those point an app
at a foreign identity provider and would break single-authority. **The SDK never
renders a login/signup screen.** When a session expires the frame calls
`bridge.requestRelaunch()` (automatically for SDK-observed 401s), then
bootstraps the fresh `joow:launch`; it never replays a consumed handle.

## Frame bridge (signals v4)

The shell and the mounted app talk over `postMessage` using the additive JooW
signal set — launch/readiness/capabilities/actions/auth/appearance plus typed
work-status, host image-upload results, and `joow:close-imminent` cleanup:

```ts
import { JoowSdk } from "@joow/sdk";

const sdk = new JoowSdk({ appId: "timebank", surface: "main" });

// Receive the postMessage-only handle, exchange it into an HttpOnly cookie
// session, remove the consumed handle from the app callback, run bootstrap,
// THEN answer ready + bridge-ready.
const bridge = sdk.attachBridge({
  allowedHostOrigin: "https://joow.org",      // REQUIRED — exact shell origin
  appId: "timebank",
  surface: "main",
  onAppearanceChange: (a) => applyTheme(a),    // locale/dir/theme/calendar/...
  onDeviceChange: (device) => applyLayout(device.mode),
  onLaunch: async () => bootstrapApp(sdk.ensureSession()),
  onLaunchError: (error) => showBootstrapError(error),
  onCloseImminent: () => flushBestEffortTelemetry(),
});

bridge.appearance;            // current shell-owned Appearance
bridge.community;             // pick-listed active tenant/session context
sdk.device.current();         // host-derived mobile/tablet/desktop context
bridge.emitAction("requestBack");   // raise a joow:action to the shell
bridge.setWorkStatus({ status: "working", label: "Saving", progress: 0.4, canClose: false });
bridge.requestRelaunch();      // host mints a FRESH handle; never uses a URL
```

**Security (hard invariant).** Every inbound `message` passes three gates:
`event.origin` must equal the canonical configured origin, `event.source` must
be the exact parent/frame `WindowProxy`, and `normalizeSignalMessage` must
recognize and pick-list the payload. Origins containing a path, query,
credentials, fragment, wildcard, non-HTTP(S) scheme, trailing slash, or
non-canonical default port are rejected at construction. Every outbound post
targets the concrete origin, never `"*"`. If launch bootstrap rejects, neither
ready signal is emitted. A slower old launch cannot report ready after a newer
launch supersedes it. Every mutable message in either direction carries exact
`app`, `appId`, `surface`, and `bridgeVersion: 4`; bare or mismatched envelopes
are dropped.

The `Appearance` object is the shell-owned render context:
`{ locale, language, direction, themeMode, resolvedTheme, timezone, calendar,
currency, textScale, reducedMotion }`. The app mirrors it and never overrides
it locally.

The launch context is deliberately narrow: exact `appId`/`surface`, appearance,
a host-derived device/layout projection, a public
`{displayName?, avatarUrl?}` user card, and an active-community
`{id, slug?, name?, role?, currency?}` projection. The user card requires
`identity.read`; community is tenant/session routing context already available
to the scoped mount and does not require a human-identity grant. All extra
runtime fields are dropped. No email, phone, raw user id, membership list,
billing data, user-agent, hardware id, or arbitrary host object crosses this
bridge.

### Device/layout context (`sdk.device`)

`sdk.device` tracks only context asserted by a verified launch or exact-context
appearance refresh. It never guesses from `navigator.userAgent` or screen
hardware. Until the host supplies a value, `sdk.device.current()` is
`undefined`.

```ts
const stop = sdk.device.subscribe(({ mode, viewportWidth, orientation }) => {
  renderFor(mode, viewportWidth, orientation);
});
```

The projection is closed to `mobile | tablet | desktop`, bounded mounted
viewport dimensions and pixel ratio, derived/declared orientation, and a touch
boolean. Unknown fields are discarded before host helpers post the signal and
again when the app receives it.

### Work and close lifecycle

`bridge.setWorkStatus()` sends the retained-app-compatible advisory envelope:
`{type, app, appId, surface, bridgeVersion: 4, status:
"idle"|"working", label?, progress?: 0..1, canClose?}`. Labels are
plain text: the SDK strips C0/C1 and bidi override/isolate controls before
normalizing whitespace and bounding the length to 120 Unicode code points.
The shell may use it to show
progress or a confirmation, but the **host owns close
policy and termination**; `canClose: false` is not a veto. The app may request
host-controlled closure with `bridge.requestClose()`. The host may send one
best-effort `joow:close-imminent` notice immediately before unmount; the live
shell currently allows about 120 ms. It does not ask permission, wait for, or
trust an acknowledgement. Inside that bounded window, `JoowSdk` gives an async
`onCloseImminent` cleanup callback at most 50 ms, then terminally disposes its
frame bridge, cached context, timers, room handles, subscriptions, and realtime
adapter authority even if that callback never settles. Callback rejection or
timeout is reported through `onMessageError` after disposal. `await
sdk.dispose()` exposes the same idempotent teardown for app-owned unmount
flows; a disposed SDK cannot be reused.

### Appearance plane (`sdk.appearance` / `sdk.user`)

The shell also speaks the compact appearance-plane pair: `joow:launch` carries
`appearance: { theme, lang, dir }` + `user: { displayName?, avatarUrl? }`, the
host re-posts `{ type: "joow:appearance", appearance, user }` on every
theme/language toggle, and an app may request a re-post with
`bridge.requestAppearance()`. Its `joow:appearance:get` carries the full exact
identity envelope. The SDK keeps
a shared cache and falls back to the platform callback
`GET /api/joow/app-sessions/{app}/appearance` when no signal has arrived:

```ts
const { appearance, user } = await sdk.appearance.get(); // {theme?,lang,dir} + card
const unsubscribe = sdk.appearance.subscribe(({ appearance, user }) => {
  applyTheme(appearance.theme);                  // 'dark' | 'light' | undefined
  document.documentElement.dir = appearance.dir; // 'ltr' | 'rtl'
});
const profile = await sdk.user.profile();        // { displayName?, avatarUrl? }
```

`get()`/`profile()` never reject — they degrade to safe defaults, because an
app must always be able to paint. The user card is the SAME public projection
`/users/discover` exposes (never an id/email/phone, D11) and the server only
includes it for sessions granting `identity.read`; the server omits `theme`
entirely (it stores no theme preference — only the shell can resolve one).
The SDK independently checks `identity.read` before exposing a bridge or HTTP
card. An omitted `user` field preserves the previous card; an explicit
`user: {}` clears it. Outbound cards are pick-listed to `displayName` and
`avatarUrl` even when callers pass a wider runtime object.

The host is the URL producer and owns media normalization: the current root
candidate resolves an allowed relative avatar against the verified shell origin
and emits only absolute HTTP(S), while invalid/non-HTTP(S) values are omitted.
The SDK's independent responsibility is capability gating, two-field
pick-listing, live retraction, and refusal to treat the card as identity.

### Reload and session recovery

Mount URLs are credential-free. On a frame reload the shell must mint and post
a fresh one-time handle. `ambientLaunchUrl`, `parseLaunchUrl`, `restore()`, and
`ambientLaunchStore` remain as deprecated 0.4.x source-compatible surfaces,
but they no longer recover or persist credentials: query/hash are stripped,
URL handle keys are ignored, and the store is a no-op.

## Why it exists (and when you don't need it)

Because the mount (`mount.go`) strips inbound `X-Joow-*` values and re-mints
trusted headers at the boundary, a mounted container can consume its scoped
platform context over plain HTTP with zero SDK import. The SDK is a **DX
accelerator, not a requirement**. On the server side, read the trusted context
directly:

```ts
import { readTrustedContext } from "@joow/sdk";

// inside your app container's HTTP handler
const ctx = readTrustedContext(req.headers);
ctx.subject;        // D13 pseudonym — the ONLY stable id you get
ctx.appId;          // your app id, minted by the platform
ctx.capabilities;   // the granted capability set
ctx.community?.id;  // community scope (no member PII)
ctx.publicIdentity; // displayName/avatarUrl only, requires identity.read

// The option is necessary but NOT authorization. The helper also verifies a
// trusted app session, host-stamped first_party tier, and the exact
// identity.attributes capability before returning private/contact fields.
const withAttributes = readTrustedContext(req.headers, {
  allowIdentityAttributes: true,
});
```

`readTrustedContext` never surfaces a raw `user_id`; `X-Joow-User-ID` carries
the **pseudonym** in v2 (P-SEC). `identity.read` may expose only the public
`displayName`/`avatarUrl` projection. Username, email, phone, first name, and
last name require all of: explicit caller opt-in, a trusted app session, the
host-stamped `first_party` tier, and the exact `identity.attributes` capability;
`identity.read`, `platformAccess`, and caller options do not imply it.

The current host has an operator-reviewed manifest/surface capability grant,
but no demonstrated per-user consent/revocation store for
`identity.attributes`. Current runnable app manifests therefore do not request
the capability. If product/privacy policy requires per-user consent, that
substrate is a blocker before enabling this capability or publicly releasing a
contract that describes it as consented.

## The client path (browser / app frontend)

```ts
import { JoowSdk } from "@joow/sdk";

const sdk = new JoowSdk({ appId: "timebank", surface: "main" });

sdk.attachBridge({
  allowedHostOrigin: "https://joow.org",
  appId: "timebank",
  surface: "main",
  onLaunch: async () => {
    // The cookie session exists here. A missing capability never leaves the client.
    const me = await sdk.identity.me();
    if (me.ok) console.log(me.data.subject); // pseudonym, never a user_id

    const feed = await sdk.social.feed();
    if (feed.ok) render(feed.data.items);

    // Card publication requires an explicit cards.publish grant; validate
    // declared kinds locally and let the platform stamp the acknowledgement.
    // Once consumed, acknowledge the exact card in this same app session:
    // await sdk.cards.acknowledge(published.data.id);
  },
});
```

Every call returns a **`JoowResult<T>`** — you branch on `.ok` / `.status`,
never on thrown errors, for expected outcomes:

| status | meaning |
|---|---|
| `ok` | success; `data` is typed |
| `not_allowed` | your session lacks the capability (never sent) |
| `not_available` | resource/operation absent or reserved (also 403/404/405) |
| `unauthorized` | 401 — session missing/expired; re-launch |
| `unavailable` | 5xx — platform is down |
| `invalid` | bad local input |

## Surfaces & capabilities

| Client | Capability | Notes |
|---|---|---|
| `device` | — | verified host-derived layout context only; no UA/hardware inference |
| `identity` | `identity.read` | pseudonymous card through `/api/joow/app-sessions/{app}/identity/me` only |
| `readTrustedContext` | `identity.attributes` | server-only private/contact attributes; exact first-party grant plus explicit opt-in; currently disabled in runnable manifests pending consent/revocation policy |
| `identity.users.discover` | `profile.read.public` | member search via `GET /api/joow/app-sessions/{app}/users/discover` — **pseudonymized results only**, raw ids/PII dropped |
| `social` | `social.read`, `social.write` | feed/post/react/report, community-scoped |
| `gpt` | `gpt.chat` | via the backend AI policy layer — no direct providers |
| `realtime` | `realtime.join`, `realtime.send` | **partial: trusted-host adapter contract only**, text-only; contract v1 atomically carries delegated authority and exact context into every open/send/list/subscribe operation; no bundled socket/host adapter; never the app-session JWT |
| `uploads.uploadImage` | `uploads.write` | exact host bridge; JPEG/PNG/WebP/GIF <=10 MiB; HTTPS result; timeout/close cleanup |
| `uploads.put` | — | reserved direct HTTP path; always `not_available`, sends nothing |
| `wallet` | `wallet.read`, `wallet.write` | **reserved/pilot-gated (OD-19: no fiat)** — zero-network until a reviewed app-session host API exists |
| `cards` | `cards.publish` | closed 27-kind validation plus exact app-session publication; host adoption, durable sink/CardHost and confirmation/exactly-once browser proof remain gated |

### Member discovery (pseudonymized)

```ts
const found = await sdk.identity.users.discover("navid", { limit: 20 });
if (found.ok) for (const u of found.data) console.log(u.subject, u.displayName);
// u.subject is a D13 pseudonym — a raw user_id / email / phone can NEVER appear.
```

Discovery is always server-scoped to the active app-session community. The
optional `communityId` is only a local assertion that it matches that active
community; it cannot select or broaden tenant scope. Queries are limited to 160
Unicode code points and limits to integers from 1 through 100 before any I/O.

### Delegated realtime token

The powerful app-session JWT is never handed to a socket. For every adapter
operation the SDK obtains a short-TTL **delegated** realtime token
(`POST /api/joow/app-sessions/{app}/realtime/token`) and passes it atomically
with the exact context in the operation object. There is no separate
authorize-then-operate step and there is no public raw-token retrieval method.
The adapter operation is the only SDK surface that receives the delegated
credential. The token cache is partitioned by immutable
session plus app, surface, community, operation, and resource; authority for
one room/operation never satisfies another:

```ts
const room = await sdk.realtime.openRoom("consultation:consultation-1");
if (!room.ok) throw new Error(room.message);

// Keep this frozen handle intact: resource is the logical authorization key;
// roomId is an opaque transport identifier returned by the trusted adapter.
const handle = room.data;
await sdk.realtime.sendMessage(handle, "hello");

const history = await sdk.realtime.listEvents(handle, { cursor: "next" });
const subscribed = await sdk.realtime.subscribe(
  handle,
  (event) => render(event),
);
subscribed.data?.(); // unsubscribe
```

`openRoom(logicalResource)` binds its returned opaque `roomId` to that exact
resource and session generation. `sendMessage`, `listEvents`, `subscribe`, and
`onMessage` accept only the bound `{resource, roomId}` handle and obtain their
own publish/subscribe authority; a string ID or reconstructed/crossed handle
fails closed. Adapter contract v1 accepts only exact `publish` or `subscribe`
targets; history reads use `subscribe` and no `list` authorization action
exists. Open results, history/live events, and publish acknowledgements echo
both resource and room ID. Legacy adapters fail the type contract and runtime
version check before token I/O. The callback-only `onMessage` convenience has
no error channel; new code should use the typed async `subscribe` result.

The mint response must carry a bounded printable token, exact bounded D11
subject, valid optional token type, and a finite expiry no more than 150
seconds away (the issuer's two-minute lifetime plus 30 seconds of clock
allowance). Optional issuer URLs must be bounded HTTPS/WSS URLs, but are
discarded and never select the transport endpoint; the trusted adapter pins
that endpoint. Missing, expired, conflicting-alias, or mismatched authority is
rejected before adapter use. A logical resource is exactly one lower-case type
plus one opaque id (`type:id`); nested colons and slash/path syntax are invalid.
Transport IDs are separate strict, bounded ASCII opaque keys. Wildcards,
whitespace, query/fragment syntax, encoded separators, and controls fail
locally.

Session adoption, launch/exchange, explicit relaunch, expiry, any realtime
platform 401, and disposal clear room bindings, token/in-flight caches, and
active subscriptions. Manual/disposed/adapter-authorization-failed/resource-
mismatch teardown also posts every exact active target to
`/api/joow/app-sessions/{app}/realtime/revoke`; a failed revoke keeps
replacement authority fail-closed. Contract v1 requires
`invalidateAuthorization(reason)`;
the SDK stops local delivery immediately, waits for adapter teardown before
arming replacement authority, and generation-guards passive expiry callbacks.
Cache entries, concurrent mints, unique targets, rooms, and live subscriptions
all have hard bounds. Room-open and subscription slots are reserved before
asynchronous authorization/adapter work, so concurrent callers cannot race
past those limits.

Platform status: current JooW source implements Ed25519 delegated tokens whose
claims bind environment, app, surface, community, D11 pseudonym, exact
canonical resource, join/signal actions, expiry, and revocation epoch. It also
implements exact app-release resource authorization and revocation callbacks.
That source has not completed independent realtime-service/stage adoption, so
this package does not claim a live authoritative edge. The adapter still
belongs in a host-trusted realm because it receives the delegated bearer; local
binding is defense in depth against app mistakes, not protection from an app
that can replace its adapter. End-to-end denial, expiry/revocation, reconnect,
origin, relay, and multi-actor stage proof remain required.

### ICE servers (calls)

For calling surfaces, `GET /api/joow/app-sessions/{app}/ice-servers` returns
the STUN/TURN set (`{ iceServers: [{ urls, username?, credential? }],
ttlSeconds? }`), parsed tolerantly:

```ts
const ice = await sdk.realtime.iceServers();
if (ice.ok) pc = new RTCPeerConnection({ iceServers: [...ice.data.iceServers] });
else if (ice.status === "not_available") useDefaultStun();  // endpoint not deployed yet
```

The endpoint may land after the SDK: a 404 is a **typed `not_available`
result**, so degrade to your defaults rather than failing the call UI.

Capabilities are **dot-scoped free-form strings** (`^[a-z]+\.[a-z_.]+$`). The
SDK ships the known v2 catalog (`CAPABILITY_CATALOG`) with legacy-alias
bridging that mirrors the backend `capability_alias.go`, but the gate accepts
**any** valid dot-scoped id — a new capability works the moment the backend
mints it, with no SDK change.

## App-owned tool runtime

`@joow/sdk/tools` is the server-side companion to the manifest authoring
contract. It verifies requests sent to `POST /_joow/tools/<name>`; it does not
mint platform tokens and exposes no signer or raw-token accessor.

```ts
import { createToolHandler, ToolEffect } from "@joow/sdk/tools";

const handleSearch = createToolHandler(
  {
    appId: "timebank",
    toolName: "search_listings",
    surface: "main",
    releaseId: process.env.JOOW_RELEASE_ID!,
    effect: ToolEffect.Read,
    verificationSecret: process.env.JOOW_PROXY_SECRET!,
    platformApiBaseUrl: process.env.JOOW_PLATFORM_API_BASE!,
    cardKinds: ["listing"],
    maxResultBytes: 65_536,
    validateInput: validateSearchInput,
    validateOutput: validateSearchOutput,
  },
  async ({ input, claims, cards }) => {
    void claims; // exact D11/community/locale/call context, never raw identity
    // `cards` may publish later while its call-scoped sink token remains live.
    return searchListings(input);
  },
);
```

Pass the exact request bytes and headers to the returned function, then write
its `statusCode`, `headers`, and already serialized JSON `body` exactly once.
`readBoundedToolBody()` can collect a Node/Web framework's raw async chunks
with the 65,536-byte ceiling applied during streaming; do not let a framework
parse or re-serialize JSON first.
The verifier enforces both broker tokens, HS256 only, issuer/audience/scope,
app/tool/surface/release, D11 subject, community, locale, call id, 120-second
maximum lifetime, and the token's SHA-256 of the exact request bytes. It also
computes `canonicalInputHash`, a deterministic sorted-key JSON hash for the
app's durable audit record. The two hashes are deliberately separate: the
current Go broker signs exact wire bytes, so changing the token claim to
canonical JSON requires a coordinated future host-contract version.

For `write` or `external`, provide a real `ToolIdempotencyStore`. Its `begin`
must atomically reserve the exact call/binding and return either `execute` or a
durably completed `replay`; `complete` must commit the output before resolving.
Only then does the SDK return
`X-Joow-Idempotency-Acknowledged: <callId>`. An in-memory map is a test double,
not a production store. The SDK does not decide whether an effect is allowed:
the platform's Twin confirmation remains authoritative before invocation.

The asynchronous `cards` publisher keeps the sink bearer in a private field,
uses only the operator-configured platform API base, refuses redirects,
performs no automatic retry, enforces the tool's declared kinds, and accepts
only the exact `202` call acknowledgement. Applications must not log, persist,
forward, or reuse inbound call/sink headers outside that one call.

Compatibility limit: because the current broker uses the same symmetric
per-app HS256 secret that the app receives, signature verification alone
cannot prove that bytes originated only from the platform. Keep every tool
endpoint private to the broker through network policy. The platform's
persisted exact sink-token digest prevents a forged sink from publishing, but
a future asymmetric call issuer or independent platform proof is still needed
to remove app-side self-forgery as a cryptographic possibility.

## Card contract

Use `validateCard(card, { appId, declaredKinds })` for local fail-fast checks;
manifest `declaredKinds` is enforced. With a usable app session and the exact
`cards.publish` grant, `sdk.cards.publish()` posts to
`/api/joow/app-sessions/{app}/cards`. The host remains authoritative: it
revalidates the active manifest and stamps the returned acknowledgement.
`sdk.cards.acknowledge(cardId)` idempotently dismisses the exact card at
`/api/joow/app-sessions/{app}/cards/{cardId}/ack`; app, D11 subject, and
community always come from the authenticated session and are never caller
parameters. These callbacks are implemented and contract-tested, but stage
adoption, reload proof, and the full 27-kind CardHost browser matrix remain
separate platform gates.

- One envelope schema tag: `joow.card.v1`.
- **The app can never self-stamp `provenance`.** `validateCard()` flags an
  object that carries it. The platform ingestion path is the sole authority
  (`ProvenanceApp` only for review-approved apps publishing a real-result kind).
- Side-effecting cards **must** set `requiresConfirmation`.
- No identity-shaped bytes (UUID / email / phone / subject-id keys) in
  `payload`/`display`/`actions` — `validateCard()` runs the same scan the
  platform's `cardpublish.go` does, so you fail fast locally.
- Kinds are exactly the closed 27-kind `CARD_KINDS_V1`; undeclared and custom
  `x-*` kinds fail closed.

## Conformance

Runnable before you publish (mirrors the backend `conformance_test.go`):

```ts
import { runConformance } from "@joow/sdk";

const report = await runConformance(
  { manifest, imports, metricLabels, cards },   // static checks
  forgeryProbe,                                  // optional D11 forgery suite
);
if (!report.passed) console.error(report.findings);
```

- **Static** (no network): manifest validates; no raw-socket import; no direct
  AI-provider import; no forbidden field in a metric/webhook label; no card
  self-stamps or leaks identity.
- **Authorization-forgery** (D11, needs a live boundary): forged Bearer
  rejected; client-supplied `X-Joow-*` rejected; leaked-key signature rejected;
  no cross-app-stable subject; self-stamped provenance stripped. Omit the probe
  until the mint lands (P-SEC) and those checks report `skipped`, not silent.

## Manifest types

`AppManifest` mirrors `manifest.go`'s lean R2 core, including `runtime`,
`cards`, `data`, `surfaces`, `proxyProof`, `presentation`, and `catalog`, and
adds the SDK contract 2.1 `tools` and `knowledge` authoring blocks.
Catalog-only entries may set `catalog: true` with an omitted or empty runtime;
launchable apps still require exactly one image/source, port, absolute health
path, netclass, an exactly-once proxy-proof secret environment binding, and
positive resource limits capped at 2 CPUs and 1 GiB using the Go authority's
canonical grammar. Source Dockerfile/context paths may normalize within the
repository but cannot be absolute, escape above its root, or use backslashes.
Source repositories accept only canonical `https://host/nonempty-path`,
`git@host:path`, and `ssh://git@host/nonempty-path` clone forms. Userinfo,
passwords, other schemes, queries/fragments, whitespace, Unicode/control or
backslash characters, escaped paths, empty/trailing/doubled paths, and dot
segments fail with a generic error that never logs the rejected value. Source
refs must be exact lowercase 40-hex commits; tags and branches are rejected.
`realtime.send` requires `realtime.join`, and capability-justification keys use
the same open dot-scoped grammar as capabilities.
Omitted surfaces default to one capability-inheriting `main` surface, and an
omitted proxy-proof mode defaults to `hmac`. Surface capability subsets cannot
invent app-wide grants, and presentation assets/labels are bounded and
validated. That schema is separate from rollout state: the current
host inventory contains 23 app manifests — 3 runnable public apps, 18
catalog-only **Coming soon** entries, and 2 nonpublic drafts. Catalog/draft
entries may omit launch-only blocks required from runnable manifests.
`data.emits` defaults to `[]` (a new app ingests **nothing** into AI/ambient).
For contract 2.1+, tool names are bounded platform namespaces; endpoints must
be exact relative `POST /_joow/tools/<name>` paths; effects are
`read|write|external`; schemas, bilingual title/description, timeout, result
size, surface, and declared card kinds are validated. Knowledge is reviewed,
digest-pinned JSONL below `/_joow/knowledge/`, limited to EN/FA locale claims,
and may reference only declared tools. `i18n` and `communityTargeting` remain
optional unpromoted extensions pending canonical code generation.

## Extensibility contract (why this won't break)

- **New capability** → allowed immediately (open dot-scoped union); add a
  catalog entry only for DX. No signature change.
- **New card kind** → additive contract-versioned const bump on both Go + TS;
  the current vocabulary is closed and custom kinds are rejected.
- **New surface/client** → add a `clients/<name>.ts` extending `BaseClient`;
  wire it in `JoowSdk`. Existing clients untouched.
- **Contract version** is stamped (`SDK_CONTRACT_VERSION`) and kept distinct
  from the npm package version. Major must match the host; minor ≤ host.
- **Sanitizer tables** (`sanitize.ts`) only ever grow. Removing an entry is a
  contract-version bump.

## Provenance of this port

The Dart v1 (`packages/joow_app_sdk`) is reference-only. Ported forward:
the safe-payload tables (`_forbiddenIdentityHeaders`, `_forbiddenFieldKeys`,
`_safeUploadResponseKeys`), the `JoowResult` capability-gating pattern, and the
connect review-before-act shape. Re-expressed in TS; the Flutter package is not
shipped on a React/TS stack. The card identity-leak scanner mirrors the Go
`cardpublish.go` (word-aware key tokens + UUID/email/phone value scan).
