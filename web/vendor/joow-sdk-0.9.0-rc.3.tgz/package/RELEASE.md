# Release and distribution

## Current decision

`@joow/sdk` `0.9.0-rc.3`, contract `2.1.0`, is the deliberate current private
source candidate and remains `private: true` and `UNLICENSED`. It adds the
explicit `@joow/sdk/testing` consumer surface and SDK/runtime compatibility
documents, and moves package tooling support from end-of-life Node 18/20 to
the active Node 22/24/26 lines, without changing the RC2 host wire contract.
Local strict typecheck, all 131 deterministic tests, and the declaration/ESM
build pass.
Pull-request CI, review, and an exact source commit are still required before
consumer adoption. No tag, registry publication, license change, host mirror,
or deployment is authorized by this candidate.

The testing surface performs no network I/O, installs no globals, creates no
production credential, and defaults to the deployed cookie-session contract.
The migration-only bearer fixture requires an explicit token. Package CI must
smoke-install the packed `@joow/sdk/testing` entry point in addition to the
existing root and server-only tools entry points.

### Previous 0.9.0-rc.2 evidence

Exact source `ede25c539b1890e39ce48224bed8c50b30a9e7f9` (tree
`80929810e0eed87873b1a7c6a9339d5e87145769`) passed ordinary CI
`29502899659` with locked install, all 127 tests, strict typecheck/build,
package allowlisting, and a clean runtime audit. Its exact 86-file
`joow-sdk-0.9.0-rc.2.tgz` is 181,080 bytes packed / 748,416 bytes unpacked and
has SHA-256
`79aeb51a2761b6d2027301ce60eca49e2e856510b8485ed17b3f35268381aa77`.
That evidence remains tied to RC2's exact source; do not rebuild a later tree
under the same version.

This candidate remains unpublished, untagged, undeployed, and unlicensed for
public use. No JooW root mirror, host/app adoption, stage deployment, or
production change is claimed. Internal adoption requires an exact reviewed
commit and separate host/app CI and acceptance evidence.

The earlier exact-code checkpoints
`5d2e016ef5ea79b5817af9c9edf97d9a6b8bf404` (tree
`4f42aace77b550b22b4ed425539a25312cc27d40`, CI `29464899544`) and
`1f4eb49b507e83bf12f990935d7c64a705019616` (tree
`418fad3d9afb3b34bcf55fa741c6834a6119eb71`, CI `29464818518`) are retained
as historical evidence and are superseded by the exact revision above.

### Historical 0.8.0 evidence

The preceding source-authority revision
`b08ceb3c51910c3172f10cf1c57fe4135744a39d` passed exact CI `29399715353`
and private no-publish RC `29399761221` with 109/109 tests. Retained artifact
`8336572615` has GitHub's server-computed digest
`sha256:f15f3563aedf17d400edfc4d555b4d7153ae28af7da7dcdd0df8cdc7b78d0226`;
the contained `joow-sdk-0.8.0.tgz` has SHA-256
`6dbdf4acb9c882d21b106856abe7a138b1b815b70bd3017fd8947497b65084d0`.

The preceding validation-authority revision
`eae95bf124ece920a6c55da505e2e73211cc41a7` passed exact CI `29398605205`
and private no-publish RC `29398638225` with 106/106 tests. Its evidence
revision `d81bb68313b623eb59e0d7ba31a5bcf53b6ec6d7` passed CI `29398772615`.
That revision superseded intermediate `e04fb0e64f3b81a0a696389d38eb2e21b7f40bdc`,
whose follow-up audit found that its memory parser accepted a leading `+` that
Go `strconv.ParseUint` rejects. All remain historical evidence.

The original 0.8.0 provenance revision
`d1de83a7e9d959bdc1824ee41e97f1df939eb0e7` passed CI `29394503122` and
private no-publish RC `29394699044`; artifact `8334607671` has digest
`sha256:de66032752a3c63428d45de15858acf8b3b275ab783c3c60397f04b75f82c354`.
Manifest-parity code revision
`f5594f311884d23cc87e32730dab68592636f4af` adds catalog, surfaces,
proxy-proof, and presentation parity with the Go authority. It passed exact CI
`29396959111` and private no-publish RC `29396994747` with 102/102 tests,
typecheck, build, clean audits, package allowlisting, packed-consumer smoke,
SBOM, checksums, and explicitly unsigned source-bound provenance. Retained
artifact `8335515162` has GitHub's server-computed digest
`sha256:491f93c8db6b534b9874f7a787b60b34e7f706a4f0d8f197c2fb14eb4c0af35c`;
the contained `joow-sdk-0.8.0.tgz` has SHA-256
`589b5f8b2ba304d438c82f6783d5593dfa793013dfe83397d91031488025c54e`.
Its evidence-document successor
`b39e86c563f4e99ccbeeaa78854097d8fc26ecb3` passed CI `29397139334`.
There is no publication, adoption, or deployment claim.
It has not been adopted by a pushed JooW root revision.
The previous 0.7.0 candidate's first code revision,
`9e63fca934620714cfc5efe1b37b9bba08db3031`, was pushed and passed exact
CI run `29360454384`. It has not been mirrored to JooW, deployed, or adopted.
No npm package has been published and no release tag exists.
The supported internal distribution method is an exact reviewed Git commit or
a source snapshot pinned by the consuming repository. This keeps the SDK, host
bridge, and backend contract auditable while repository access, license, and
registry policy remain owner decisions.

Do not remove `private: true`, create a tag, or run `npm publish` as part of an
ordinary SDK change.

The previous exact 0.6.0 candidate revision
`a868cf1e325a1a90dbc0aac2e4558c187852df52` passed standalone CI run
`29326781985`, including locked install, typecheck, 72 contract tests, build,
package allowlist, and runtime audit. This verifies that source revision; it
does not publish, license, tag, or prove host adoption of 0.7.0.

The 0.7.0 candidate passes locked install, strict typecheck,
92/92 tests, declaration/ESM build, zero-vulnerability runtime/full audits, an
82-file package allowlist (600,579 unpacked bytes), packed-consumer runtime
smoke, metadata/KG integrity, diff whitespace, generated-path, and credential-
pattern checks. Deterministic tests include adapter-version, concurrency,
cross-resource handle/event/acknowledgement, expiry, standalone ICE renewal,
401 teardown, bounded churn, disposal, and operation-vocabulary cases. The
first manual no-publish RC run, `29360505888`, passed every source, audit,
package, SBOM, consumer, and checksum step, then failed because GitHub-hosted
artifact attestations are unavailable for this user-owned private repository.
It produced no retained artifact because the upload step correctly did not run
after that failure. The current follow-up records this limitation explicitly
and must pass its own exact-commit CI/evidence run before host or app adoption.

JooW root `5d2807149cc40aaeb04cfd05f6d681a4c6e13533` contains the
synchronized 0.6.0 source/documents and passed targeted stage run `29347541134`
with JooWFak runtime `d011ca049b4d031b8fd185f87ac338a73bcb1d79`
after app CI `29346907089`. Signed-in browser proof covered canonical identity
and realtime grants, public-card propagation with the expected fallback,
locale/theme/device, search without a standalone-account/name prompt, and
Working/force-close/cancel state. The host profile had no uploaded avatar, so
the browser did not prove an avatar image load; static/CI coverage proves URL
normalization. Later app documentation is at
`32055789603a5b0ee74d7915f3ecce1aeb0ac025`, while the deployed runtime pin
remains `d011ca0`. Production was unchanged. Treat this as one accepted targeted
host/app slice, not a public release or complete three-app/surface compatibility
matrix.

The earlier 0.5.1 code revision
`cb0fabdc644a479a0ec66ee3552e9f80dd1fc665` passed standalone CI run
`29300386031`. The main JooW tree containing that synchronized 0.5.1 boundary
passed full stage workflow `29301375540` at
`b0a92dc4ff8a47a90682da2a7cbf320436b61a53`. That host adoption is necessary
historical evidence only. The standalone CI pass itself did not synchronize
the host; later root revisions did and the targeted JooWFak stage slice above
passed. It is not a tag, publication, license grant, or complete consuming-app
browser compatibility matrix.

## Historical 0.6.0 three-app adoption evidence

Independent candidate CI is green for TimeBank
`eff81067d7f2a6e732c010eb2c518e6e039c5a4e` / `29343715025`, JooWFak
`d011ca049b4d031b8fd185f87ac338a73bcb1d79` / `29346907089`, and
KhodroJoow `625ef849d62418a7d2364189cb1958ed98631d41` / `29341691350`.
Together their source tests exercise the canonical public identity projection,
locale/theme/device updates, retained work/non-vetoable close, host uploads,
and delegated realtime contracts in different combinations. JooWFak
additionally passed the targeted root stage slice recorded above. They do not
prove complete provider availability or public third-party compatibility. This
is protocol/provider adoption, not evidence that a published npm artifact was
consumed; no such artifact exists.

## Release-candidate scope

Implemented and locally contract-tested through 0.9.0-rc.3: cookie-first launch/exchange,
exact-origin/source/context bridge handling, appearance and device context,
tenant community context, public identity, and app-scoped pseudonymous member
discovery; contract 2.1 tool/knowledge manifest authoring; and capability-gated
card publication over the exact app-session callback.

Partial or reserved surfaces must remain described as such:

- realtime supplies versioned delegated-token operation contracts only; it
  ships no socket transport and exposes no app-client raw-token retrieval.
  Contract v1 binds logical resources to opaque room IDs, atomically carries
  immutable authority, requires exact open/event/publish-ack envelopes and
  adapter teardown, bounds local authority state, and discards it on expiry,
  401, mismatch, or disposal. Canonical `type:id` targets are included in every
  mint request; manual/disposed/authorization-failed/resource-mismatch paths
  invoke exact platform revocation and remain fail-closed on failure. JooW
  source now implements signed resource/action claims and revocation epochs,
  but the independent realtime edge and stage proof remain open. The adapter
  credential boundary is approved only in a host-trusted realm;
- wallet is a forward-compatible internal-credit shape whose capabilities are
  pilot-gated and unavailable today. The SDK sends no guessed wallet request;
  the existing signup-credit tables are not an app API. A host-owned,
  app-session/community-scoped read contract and a separately reviewed,
  Twin-confirmed idempotent mutation contract are backend prerequisites;
- tool runtime verification, bounded schema adapters, durable idempotency
  orchestration, and a private asynchronous card sink are implemented in RC2.
  Consuming apps still need real durable stores,
  framework adapters/header-log redaction, exact release configuration, and
  stage host/app acceptance;
- card validation and authenticated platform publication are implemented and
  locally contract-tested for the exact closed 27 kinds. Full host adoption,
  durable asynchronous sink acknowledgement, reload persistence, generic
  CardHost rendering, and confirmation/exactly-once browser proof remain open;
- host-mediated image upload exists, while direct HTTP upload is reserved;
- ICE discovery may return `not_available` until its endpoint is deployed;
- `identity.attributes` remains disabled in runnable manifests pending the
  consent/revocation policy decision;
- social/GPT client contracts are typed and capability-gated, but this
  standalone package CI is not end-to-end host/backend compatibility proof.

## Release-candidate verification

Run from a clean checkout:

```sh
npm ci
npm run typecheck
npm test
npm run build
npm audit --omit=dev
npm audit
npm pack --dry-run --json
```

Inspect the pack manifest. It must contain only `dist/`, `package.json`, and the
shipped documentation/license files listed by `package.json#files`; it
must not contain tests, source maps with local paths, credentials, `.env`, Git
metadata, plans, or the knowledge graph.

For owner-reviewed private evidence, manually dispatch
`.github/workflows/release-candidate.yml` from a branch. It verifies the
checked-out SHA, `private: true`/`UNLICENSED` posture and exact 0.9.0-rc.3 package;
uses the Ubuntu 24.04 runner label, an exact Node/npm toolchain, and full commit
pins for every imported action; runs source gates and full/runtime audits;
builds and smoke-installs the exact `joow-sdk-0.9.0-rc.3.tgz`; rejects duplicate,
unsafe, missing, archive/manifest-mismatched, or non-allowlisted packed paths;
emits the pack manifest, a CycloneDX npm SBOM, an unsigned in-toto/SLSA
source-bound provenance statement, and `SHA256SUMS`; validates every recorded
subject digest; uploads the complete private evidence; records GitHub's
server-computed artifact digest; and retains the evidence for 30 days. This is
source-bound review metadata, not a cryptographically authenticated
attestation and not a claim that the SBOM or runner image is byte-for-byte
reproducible. [GitHub's documented availability rules](https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations)
require Enterprise Cloud for hosted attestations in private repositories; the
repository is not made public to bypass that limit.
The workflow has no npm publish, Git tag, release, mirror, or deployment step,
and a successful run is not public-release authorization.

## Gates before public npm publication

All items require explicit owner approval:

- choose an open-source or commercial license and update `LICENSE` plus
  `package.json#license` consistently;
- decide whether and how the currently private GitHub repository becomes
  readable to public integrators, with an immutable source/tag policy;
- choose the npm organization, access policy, package ownership, and support
  channel;
- reserve/verify the package name and document compatibility policy;
- enable npm trusted publishing, immutable tags, 2FA, and a protected release
  environment; the private RC provenance workflow is evidence only;
- choose and fund a private cryptographic provenance path (for example GitHub
  Enterprise Cloud attestations or an owner-approved private KMS/signing
  policy), or explicitly authorize a public repository. The current unsigned
  source-bound statement is not a substitute for signed release provenance;
- add a separately owner-approved publication job that builds from a protected
  tag and publishes exactly the verified tarball (never a developer workstation
  build); do not extend the no-publish RC workflow implicitly;
- complete dependency, secret, license, API-extractor, and consumer smoke-test
  review;
- complete the supported consuming-app/surface browser matrix, including
  reload/relaunch, session expiry, upload, retained work/force-close, and
  hostile/sibling-origin cases;
- remove or formally time-bound the migration-only `allowLegacyBearer` escape
  hatch after proving all supported backends use cookie sessions;
- obtain host/backend compatibility sign-off and update the consuming repos to
  the released version only after the package digest is recorded;
- adopt and prove the v1 host/SDK/edge realtime adapter path, including exact
  subscribe/publish enforcement, logical-resource/opaque-room envelopes,
  publish acknowledgements, old-transport teardown, endpoint pinning, and
  expiry/401/disposal behavior and exact platform revoke behavior. Before
  third-party adoption, prove the new signed resource/action/revocation path at
  the independent edge and keep delegated credentials in a host-trusted
  adapter; otherwise narrow the public SDK promise to trusted first-party
  integrations only;
- keep wallet, direct upload, and undeployed ICE operations out of public
  availability claims; keep card publication out until host adoption, durable
  acknowledgement, CardHost, confirmation/exactly-once, and browser gates pass;
- define and enforce external-app trust-tier admission, review, recertification,
  revocation, and support ownership instead of extrapolating from three pilots;
- replace shared stage-network/database-superuser residuals with proven hostile-
  tenant process/data containment and per-app ingress/egress/network policy;
- before enabling `identity.attributes`, either implement and verify the
  required per-user consent/revocation model or record an owner/privacy ruling
  that the explicit operator-reviewed first-party grant is sufficient; never
  describe the current coarse grant as consented without that evidence.

Until every gate is closed, exact-commit source distribution is the truthful
strategy.

The historical 2026-07-14 JooW root frontend audit snapshot (three high and one
moderate development-tool advisories, runtime clean) was resolved on
2026-07-15. Current root frontend and standalone SDK full/runtime audits each
report zero vulnerabilities. That audit-specific gate is closed, but this does
not waive the dependency, secret, license, or compatibility reviews above.
